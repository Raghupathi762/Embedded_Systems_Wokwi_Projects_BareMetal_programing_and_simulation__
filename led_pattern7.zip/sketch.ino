#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  uint8_t a[3]={0x07,0xE0,0x18};
  uint8_t i=0;
  ddra=0xff;
  while(1)
  {
 porta=(a[i]);
 delay();
 i++;
 if(i==3)
 i=0;
}
}