#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  uint8_t a[4]={0,6,2,4};
  uint8_t i=0;
  ddra=0xff;
  while(1)
  {
 porta=(3<<a[i]);
 delay();
 i++;
 if(i==4)
 i=0;
}
}