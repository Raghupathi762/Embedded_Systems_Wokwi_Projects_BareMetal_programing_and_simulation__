#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  ddra=0xff;
  while(1)
  {
    porta=0x11;
    delay();
      porta=0x22;
    delay();
     porta=0x44;
    delay();
      porta=0x88;
    delay();
  }
}