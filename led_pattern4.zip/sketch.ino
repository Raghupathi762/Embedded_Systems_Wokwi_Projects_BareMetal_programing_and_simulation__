#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  uint8_t a[8]={0,2,1,3,4,6,5,7};
  uint8_t i=0;
  ddra=0xff;
  while(1)
  {
 porta=(1<<a[i]);
 delay();
 i++;
 if(i==8)
 i=0;
}
}