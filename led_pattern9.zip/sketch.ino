#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{uint8_t a[8]={0x01,0x03,0x07,0x0f,0x1f,0x3f,0x7f,0xff};
  uint8_t i=0;
  ddra=0xff;
  while(1)
  {
 porta=a[i];
 delay();
 porta=0x00;
 delay();
 i++;
 if(i==8)
 i=0;

}
}