#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{uint8_t a[8]={0x80,0xC0,0xE0,0xf0,0xf8,0xfC,0xFE,0xFF};
  uint8_t i=0;
  ddra=0xff;
  while(1)
  {
 porta=a[i];
 delay();
 porta=0x00;
 delay();
 i++;
 if(i==8)
 i=0;

}
}