#include<stdint.h>
#define porta (*(volatile uint8_t*)(0x22))
#define  ddra  (*(volatile uint8_t*)(0x21))
void delay()
{
  volatile uint32_t i;
  for(i=0;i<400000;i++);
}
int main(void)
{
  uint8_t value=0;
  uint8_t dir=1;
  ddra=0xff;
  while(1)
  {
  porta=1<<value;
  delay();
value=value+dir;
if(value==7)
dir=-1;
else if(value==0)
dir=1;
  }
}